<?php


session_start();

session_unset();
session_destroy();

// Insert when user loged out
$userId = $row['user_id'];
$loginDetails = ("UPDATE users SET user_login = 0 WHERE user_id = '$userId'");
mysqli_query( $conn, $loginDetails );

header("Location: ../");
exit();